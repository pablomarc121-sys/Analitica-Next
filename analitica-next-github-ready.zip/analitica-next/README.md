# Analítica Veterinaria Next.js

Aplicación web preparada para desplegar en Vercel. Permite subir una analítica veterinaria en PDF desde ordenador o móvil y genera una salida clínica profesional para copiar en la ficha del paciente.

- Texto breve para copiar en la ficha clínica.
- Sugerencias diagnósticas.
- Abordaje sugerido.
- Estudio del gráfico hematológico basado en flags, patrón analítico y avisos textuales.
- Tabla de valores fuera de rango o de interés clínico.

## Privacidad

- La app no usa base de datos.
- La app no usa `localStorage`, `sessionStorage` ni cookies propias para guardar analíticas.
- El PDF se envía a `/api/analyze`, se procesa en memoria en el servidor y se devuelve solo el resultado estructurado.
- El texto bruto extraído del PDF no se muestra ni se conserva en el navegador.
- Si se pega texto manualmente, se borra del campo tras analizarlo.
- En Vercel, la función serverless no conserva el archivo tras la petición.

## Contenido clínico integrado

- Anemia por hematocrito y especie, morfología, reticulocitos y proteínas.
- Hemoconcentración, leucograma de estrés/corticoides, trombocitopenia, eosinofilia.
- Creatinina >2 como hallazgo de interés aunque el laboratorio use rangos más amplios.
- Lipasa pancreática Catalyst/Spec cPL: 200-400 dudoso, >400 sugestivo de pancreatitis.
- Addison: ratio Na/K, cortisol basal y test de estimulación con ACTH.
- Cushing: ACTH-stim en perro, limitaciones en gato y LDDST/UCCR si aparecen.

## Requisitos

- Node.js 18.17 o superior.
- npm.

## Ejecutar en local

```bash
npm install
npm run dev
```

Abrir `http://localhost:3000`.

## Preparar para GitHub

Desde la carpeta `analitica-next`:

```bash
git init
git add .
git commit -m "Initial Next.js veterinary analytics app"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

## Desplegar en Vercel

1. Subir esta carpeta a un repositorio de GitHub.
2. En Vercel, crear un proyecto nuevo e importar el repositorio.
3. Framework preset: `Next.js`.
4. Build command: `npm run build`.
5. Output: automático.
6. Si no vas a usar login, no hace falta configurar variables de entorno.

## Supabase Auth opcional

La app está preparada para activar login con Supabase Auth, pero viene desactivado por defecto.

1. Crea un proyecto en Supabase.
2. Copia `.env.example` a `.env.local`.
3. Rellena:

```bash
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
NEXT_PUBLIC_SUPABASE_AUTH_ENABLED=true
SUPABASE_AUTH_ENABLED=true
```

4. En Vercel, añade esas mismas variables en Project Settings > Environment Variables.

Cuando `SUPABASE_AUTH_ENABLED=true`, la ruta `/api/analyze` exige sesión Supabase antes de procesar analíticas. El proyecto incluye los clientes base en:

- `lib/supabase-browser.js`
- `lib/supabase-server.js`
- `/login`
- `/auth/callback`

El login incluido usa magic link por email. En Supabase debes añadir la URL de producción de Vercel en Authentication > URL Configuration, por ejemplo:

- Site URL: `https://tu-app.vercel.app`
- Redirect URL: `https://tu-app.vercel.app/auth/callback`

## Usuario y contraseña simple

Para proteger toda la app con usuario y contraseña tipo navegador, configura estas variables:

```bash
BASIC_AUTH_USER=...
BASIC_AUTH_PASSWORD=...
```

Si estas variables están vacías, la protección básica queda desactivada.

## Comandos útiles

```bash
npm run dev
npm run build
npm run start
```
