"use client";

import { useState } from "react";
import { Activity, Clipboard, FileText, Loader2, RefreshCw, UploadCloud } from "lucide-react";
import { labelFinding } from "@/lib/analysis";

function InfoCard({ title, badge, children, tone = "default" }) {
  return (
    <section className={`card ${tone}`}>
      <div className="cardHead">
        <h2>{title}</h2>
        {badge ? <span>{badge}</span> : null}
      </div>
      <div className="cardBody">{children}</div>
    </section>
  );
}

function List({ items }) {
  return (
    <ul className="clinicalList">
      {items.map((item) => (
        <li key={item}>{item}</li>
      ))}
    </ul>
  );
}

export default function Page() {
  const authEnabled = process.env.NEXT_PUBLIC_SUPABASE_AUTH_ENABLED === "true";
  const [manualText, setManualText] = useState("");
  const [result, setResult] = useState(null);
  const [fileName, setFileName] = useState("");
  const [status, setStatus] = useState("Sube una analítica IDEXX/VetConnect en PDF o pega el texto extraído.");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  async function handleFile(file) {
    if (!file) return;
    setBusy(true);
    setFileName(file.name);
    setStatus("Leyendo PDF...");
    setCopied(false);

    try {
      const form = new FormData();
      form.append("file", file);
      const response = await fetch("/api/analyze", { method: "POST", body: form });
      const payload = await response.json();
      if (!payload.ok) throw new Error(payload.error || "No se ha podido analizar el PDF.");
      setResult(payload.result);
      setStatus("PDF analizado correctamente.");
    } catch (error) {
      setResult({ error: error?.message || "No se ha podido analizar el PDF." });
      setStatus(error?.message || "No se ha podido analizar el PDF.");
    } finally {
      setBusy(false);
    }
  }

  async function analyzeManualText() {
    if (!manualText.trim()) return;
    setBusy(true);
    setStatus("Analizando texto...");
    setCopied(false);

    try {
      const form = new FormData();
      form.append("text", manualText);
      const response = await fetch("/api/analyze", { method: "POST", body: form });
      const payload = await response.json();
      if (!payload.ok) throw new Error(payload.error || "No se ha podido analizar el texto.");
      setResult(payload.result);
      setManualText("");
      setStatus("Texto analizado correctamente. El texto bruto no se conserva en el navegador.");
    } catch (error) {
      setResult({ error: error?.message || "No se ha podido analizar el texto." });
      setStatus(error?.message || "No se ha podido analizar el texto.");
    } finally {
      setBusy(false);
    }
  }

  async function copyToClipboard() {
    if (!result?.copyText) return;
    await navigator.clipboard.writeText(result.copyText);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  function clearAll() {
    setManualText("");
    setResult(null);
    setFileName("");
    setCopied(false);
    setStatus("Sube una analítica IDEXX/VetConnect en PDF o pega el texto extraído.");
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">Hospital veterinario</p>
          <h1>Analítica veterinaria</h1>
        </div>
        <div className="topActions">
          {authEnabled ? (
            <a className="ghostButton" href="/login">
              Acceso
            </a>
          ) : null}
          <button type="button" className="ghostButton" onClick={clearAll} title="Limpiar">
            <RefreshCw size={18} />
            <span>Limpiar</span>
          </button>
        </div>
      </header>

      <section className="workspace">
        <aside className="inputPanel">
          <label
            className={`dropzone ${busy ? "loading" : ""}`}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              handleFile(event.dataTransfer.files?.[0]);
            }}
          >
            {busy ? <Loader2 className="spin" size={28} /> : <UploadCloud size={30} />}
            <strong>{fileName || "Subir PDF"}</strong>
            <span>{busy ? "Extrayendo texto" : "Arrastra el archivo o selecciónalo"}</span>
            <input
              type="file"
              accept="application/pdf"
              onChange={(event) => handleFile(event.target.files?.[0])}
            />
          </label>

          <div className="statusLine">{status}</div>

          <label className="textInput">
            <span>Texto manual opcional</span>
            <textarea
              value={manualText}
              onChange={(event) => {
                setManualText(event.target.value);
                setCopied(false);
              }}
              placeholder="Pega texto solo si no tienes el PDF. Se borra tras analizarlo."
            />
            <button type="button" className="secondaryButton" onClick={analyzeManualText} disabled={busy || !manualText.trim()}>
              <Activity size={18} />
              <span>Analizar texto</span>
            </button>
          </label>
        </aside>

        <section className="resultPanel">
          {!result ? (
            <div className="emptyState">
              <FileText size={42} />
              <h2>Sin analítica cargada</h2>
              <p>Cuando subas un PDF verás aquí el texto para ficha, los hallazgos y la interpretación clínica.</p>
            </div>
          ) : result.error ? (
            <div className="emptyState errorState">
              <Activity size={42} />
              <h2>No se ha podido analizar</h2>
              <p>{result.error}</p>
            </div>
          ) : (
            <>
              <section className="summaryBand">
                <div>
                  <span>Paciente</span>
                  <strong>{result.patient.name || "No identificado"}</strong>
                </div>
                <div>
                  <span>Especie</span>
                  <strong>{result.patient.species || "-"}</strong>
                </div>
                <div>
                  <span>Edad</span>
                  <strong>{result.patient.age || "-"}</strong>
                </div>
                <div>
                  <span>Hallazgos</span>
                  <strong>{result.findings.length}</strong>
                </div>
              </section>

              {result.criticalAlerts?.length ? (
                <section className="criticalAlerts" aria-label="Avisos clínicos importantes">
                  {result.criticalAlerts.map((alert) => (
                    <article className="criticalAlert" key={alert.title}>
                      <div>
                        <span>Aviso importante</span>
                        <h2>{alert.title}</h2>
                        <p>{alert.message}</p>
                      </div>
                      <ul>
                        {alert.actions.map((action) => (
                          <li key={action}>{action}</li>
                        ))}
                      </ul>
                    </article>
                  ))}
                </section>
              ) : null}

              <InfoCard title="Texto para ficha" badge="Copiable" tone="copy">
                <pre className="copyBox">{result.copyText}</pre>
                <button type="button" className="primaryButton" onClick={copyToClipboard}>
                  <Clipboard size={18} />
                  <span>{copied ? "Copiado" : "Copiar"}</span>
                </button>
              </InfoCard>

              <InfoCard title="Sugerencias diagnósticas" badge={result.suggestions.length}>
                <List items={result.suggestions} />
              </InfoCard>

              <InfoCard title="Abordaje sugerido" badge={result.followup.length}>
                <List items={result.followup} />
              </InfoCard>

              <InfoCard title="Estudio del gráfico hematológico" badge={result.graph.length}>
                <List items={result.graph} />
                <p className="smallNote">Basado en flags, patrón del hemograma y avisos textuales. Si el scattergram visual muestra poblaciones dudosas, confirmar con revisión manual y frotis.</p>
              </InfoCard>

              <InfoCard title="Valores fuera de rango / interés" badge={result.abnormal.length}>
                <div className="tableWrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Parámetro</th>
                        <th>Resultado</th>
                        <th>Referencia</th>
                        <th>Flag</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.abnormal.map((row, index) => (
                        <tr key={`${row.key}-${index}`}>
                          <td>
                            <strong>{labelFinding(row).split(":")[0]}</strong>
                            <small>{row.name}</small>
                          </td>
                          <td>{row.value}{row.unit ? ` ${row.unit}` : ""}</td>
                          <td>{row.low ? `${row.low}-${row.high}` : "-"}</td>
                          <td>{row.flag || "Interés"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </InfoCard>
            </>
          )}
        </section>
      </section>
    </main>
  );
}
