import "./globals.css";

export const metadata = {
  title: "Analítica Veterinaria",
  description: "Transcriptor e interpretador clínico de analíticas veterinarias"
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
