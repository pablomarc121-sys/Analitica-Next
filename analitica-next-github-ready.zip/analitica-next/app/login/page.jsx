"use client";

import { useState } from "react";
import { LogIn } from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase-browser";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("Introduce tu email para recibir un enlace de acceso.");
  const [busy, setBusy] = useState(false);

  async function signIn(event) {
    event.preventDefault();
    setBusy(true);

    try {
      const supabase = createSupabaseBrowserClient();
      if (!supabase) throw new Error("Faltan variables de entorno de Supabase.");

      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      });

      if (error) throw error;
      setStatus("Revisa tu email para acceder.");
    } catch (error) {
      setStatus(error?.message || "No se ha podido enviar el enlace.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="loginShell">
      <form className="loginCard" onSubmit={signIn}>
        <LogIn size={30} />
        <h1>Acceso clínico</h1>
        <p>{status}</p>
        <label>
          <span>Email</span>
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="tu@email.com"
            required
          />
        </label>
        <button type="submit" className="primaryButton" disabled={busy}>
          {busy ? "Enviando..." : "Enviar enlace"}
        </button>
      </form>
    </main>
  );
}
