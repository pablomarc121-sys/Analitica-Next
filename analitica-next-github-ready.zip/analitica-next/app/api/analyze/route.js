import pdf from "pdf-parse";
import { analyzeText } from "@/lib/analysis";
import { createSupabaseServerClient } from "@/lib/supabase-server";

export const runtime = "nodejs";
export const maxDuration = 30;

async function requireSessionIfEnabled() {
  if (process.env.SUPABASE_AUTH_ENABLED !== "true") return null;

  const supabase = createSupabaseServerClient();
  if (!supabase) {
    return Response.json(
      { ok: false, error: "Supabase Auth está activado pero faltan variables de entorno." },
      { status: 500 }
    );
  }

  const { data, error } = await supabase.auth.getUser();
  if (error || !data?.user) {
    return Response.json({ ok: false, error: "Sesión requerida." }, { status: 401 });
  }

  return null;
}

export async function POST(request) {
  const authError = await requireSessionIfEnabled();
  if (authError) return authError;

  try {
    const form = await request.formData();
    const file = form.get("file");
    const pastedText = String(form.get("text") || "");
    let text = pastedText.trim();

    if (!text && file && typeof file.arrayBuffer === "function") {
      const buffer = Buffer.from(await file.arrayBuffer());
      const result = await pdf(buffer);
      text = result.text || "";
    }

    if (!text) {
      return Response.json({ ok: false, error: "No se ha recibido ningún PDF ni texto." }, { status: 400 });
    }

    return Response.json({ ok: true, result: analyzeText(text) });
  } catch (error) {
    return Response.json(
      { ok: false, error: error?.message || "No se ha podido analizar la analítica." },
      { status: 500 }
    );
  }
}
