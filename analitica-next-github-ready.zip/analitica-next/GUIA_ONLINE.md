# Publicar la app online

Esta app está preparada para desplegarse en Vercel y poder abrirse desde cualquier ordenador o móvil con un enlace web.

## Opción recomendada: GitHub + Vercel

### 1. Crear un repositorio en GitHub

1. Entra en https://github.com.
2. Crea un repositorio nuevo, por ejemplo `analitica-veterinaria`.
3. No hace falta añadir README desde GitHub, la carpeta ya lo tiene.

### 2. Subir la carpeta a GitHub

Desde la carpeta `analitica-next`, ejecutar:

```bash
git init
git add .
git commit -m "Initial veterinary analytics web app"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/analitica-veterinaria.git
git push -u origin main
```

### 3. Publicar en Vercel

1. Entra en https://vercel.com.
2. Conecta tu cuenta de GitHub.
3. Pulsa `Add New Project`.
4. Selecciona el repositorio `analitica-veterinaria`.
5. Vercel detectará automáticamente que es una app Next.js.
6. Pulsa `Deploy`.

Al terminar, Vercel generará una URL del tipo:

```text
https://analitica-veterinaria.vercel.app
```

Esa URL se podrá abrir desde cualquier ordenador o móvil.

## Variables de entorno

Si NO quieres login, no necesitas configurar nada.

Si quieres activar login con Supabase Auth, añade estas variables en Vercel:

```bash
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
NEXT_PUBLIC_SUPABASE_AUTH_ENABLED=true
SUPABASE_AUTH_ENABLED=true
```

Con login activado, la ruta `/api/analyze` exige sesión antes de procesar analíticas.

## Privacidad

- No hay base de datos.
- No se guardan analíticas.
- No se usa `localStorage` ni `sessionStorage`.
- El PDF se procesa en servidor y solo se devuelve el informe estructurado.
- La app está pensada para procesar la analítica y olvidar el archivo al terminar la petición.

## Probar antes de publicar

```bash
npm install
npm run dev
```

Abrir:

```text
http://localhost:3000
```

## Comprobar build de producción

```bash
npm run build
```

Si el build funciona localmente, Vercel debería desplegarlo sin problemas.

## Alternativa: Render

Esta carpeta también incluye `Dockerfile` y `render.yaml`, por lo que puede desplegarse en Render.

1. Sube el proyecto a GitHub.
2. Entra en https://render.com.
3. Crea un nuevo `Web Service`.
4. Conecta el repositorio.
5. Render detectará `render.yaml` o el `Dockerfile`.
6. Añade variables de entorno:

```bash
BASIC_AUTH_USER=marc
BASIC_AUTH_PASSWORD=CAMBIA_ESTA_PASSWORD
NEXT_PUBLIC_SUPABASE_AUTH_ENABLED=false
SUPABASE_AUTH_ENABLED=false
```

7. Pulsa `Deploy`.

Render te dará una URL HTTPS del tipo:

```text
https://analitica-veterinaria.onrender.com
```

La app quedará protegida con usuario y contraseña.
