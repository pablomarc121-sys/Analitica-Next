import pdf from "pdf-parse";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(request) {
  try {
    const form = await request.formData();
    const file = form.get("file");

    if (!file || typeof file.arrayBuffer !== "function") {
      return Response.json({ ok: false, error: "No se ha recibido ningún PDF." }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const result = await pdf(buffer);

    return Response.json({ ok: true, text: result.text || "" });
  } catch (error) {
    return Response.json(
      { ok: false, error: error?.message || "No se ha podido leer el PDF." },
      { status: 500 }
    );
  }
}
